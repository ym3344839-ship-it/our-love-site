function showSurprise(){
document.getElementById('popup').style.display='flex';
}

function closeSurprise(){
document.getElementById('popup').style.display='none';
}
